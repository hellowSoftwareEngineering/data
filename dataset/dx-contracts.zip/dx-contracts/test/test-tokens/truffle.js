const truffleConfig = require('../../truffle')

module.exports = truffleConfig
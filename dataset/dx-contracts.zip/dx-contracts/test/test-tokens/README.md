# Rinkeby test tokens
Just a small truffle project to deploy test tokens for testing in rinkeby.

# Install dependencies
```bash
yarn install
```

# Deploy in rinkeby
```bash
yarn migrate --network rinkeby
```
